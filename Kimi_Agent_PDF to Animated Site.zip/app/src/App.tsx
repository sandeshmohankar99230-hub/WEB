import { useEffect, useRef, useState } from 'react';
import { motion, useScroll, useTransform, useInView } from 'framer-motion';
import { 
  Play, 
  Film, 
  Palette, 
  Sparkles, 
  Clapperboard, 
  Wand2, 
  Users,
  Mail,
  Phone,
  MapPin,
  GraduationCap,
  Briefcase,
  Globe,
  Download,
  ExternalLink
} from 'lucide-react';
import { Button } from '@/components/ui/button';

// Animated background particles component
const ParticleBackground = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    
    const particles: Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
      size: number;
      opacity: number;
    }> = [];
    
    for (let i = 0; i < 50; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        size: Math.random() * 2 + 1,
        opacity: Math.random() * 0.5 + 0.2
      });
    }
    
    let animationId: number;
    
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      particles.forEach((particle, i) => {
        particle.x += particle.vx;
        particle.y += particle.vy;
        
        if (particle.x < 0 || particle.x > canvas.width) particle.vx *= -1;
        if (particle.y < 0 || particle.y > canvas.height) particle.vy *= -1;
        
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(6, 182, 212, ${particle.opacity})`;
        ctx.fill();
        
        // Draw connections
        particles.slice(i + 1).forEach((other) => {
          const dx = particle.x - other.x;
          const dy = particle.y - other.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          
          if (distance < 150) {
            ctx.beginPath();
            ctx.moveTo(particle.x, particle.y);
            ctx.lineTo(other.x, other.y);
            ctx.strokeStyle = `rgba(6, 182, 212, ${0.1 * (1 - distance / 150)})`;
            ctx.stroke();
          }
        });
      });
      
      animationId = requestAnimationFrame(animate);
    };
    
    animate();
    
    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    
    window.addEventListener('resize', handleResize);
    
    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);
  
  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-0"
      style={{ opacity: 0.6 }}
    />
  );
};

// Navigation component
const Navigation = () => {
  const [scrolled, setScrolled] = useState(false);
  
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const navItems = [
    { label: 'About', href: '#about' },
    { label: 'Experience', href: '#experience' },
    { label: 'Skills', href: '#skills' },
    { label: 'Education', href: '#education' },
    { label: 'Contact', href: '#contact' },
  ];
  
  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'glass-strong py-3' : 'py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <motion.a
          href="#"
          className="text-xl font-bold gradient-text"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          SM
        </motion.a>
        
        <div className="hidden md:flex items-center gap-8">
          {navItems.map((item, index) => (
            <motion.a
              key={item.label}
              href={item.href}
              className="text-sm text-muted-foreground hover:text-foreground transition-colors relative group"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 + 0.3 }}
              whileHover={{ y: -2 }}
            >
              {item.label}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-cyan-500 to-violet-500 group-hover:w-full transition-all duration-300" />
            </motion.a>
          ))}
        </div>
        
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
        >
          <Button 
            size="sm" 
            className="btn-shine bg-gradient-to-r from-cyan-500 to-violet-500 hover:from-cyan-600 hover:to-violet-600"
          >
            <Download className="w-4 h-4 mr-2" />
            Resume
          </Button>
        </motion.div>
      </div>
    </motion.nav>
  );
};

// Hero Section
const HeroSection = () => {
  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 500], [0, 150]);
  const y2 = useTransform(scrollY, [0, 500], [0, -100]);
  const opacity = useTransform(scrollY, [0, 300], [1, 0]);
  
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Animated gradient orbs */}
      <motion.div
        className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full"
        style={{
          background: 'radial-gradient(circle, rgba(6, 182, 212, 0.3) 0%, transparent 70%)',
          y: y1,
        }}
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.5, 0.8, 0.5],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />
      
      <motion.div
        className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full"
        style={{
          background: 'radial-gradient(circle, rgba(139, 92, 246, 0.3) 0%, transparent 70%)',
          y: y2,
        }}
        animate={{
          scale: [1.2, 1, 1.2],
          opacity: [0.5, 0.8, 0.5],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />
      
      <motion.div 
        className="relative z-10 text-center px-6 max-w-4xl mx-auto"
        style={{ opacity }}
      >
        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-8"
        >
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          <span className="text-sm text-muted-foreground">Available for work</span>
        </motion.div>
        
        {/* Name */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-5xl md:text-7xl lg:text-8xl font-bold mb-4 tracking-tight"
        >
          <span className="gradient-text">SANDESH</span>
        </motion.h1>
        
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="text-5xl md:text-7xl lg:text-8xl font-bold mb-8 tracking-tight"
        >
          MOHANKAR
        </motion.h1>
        
        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="flex items-center justify-center gap-4 mb-8"
        >
          <Clapperboard className="w-6 h-6 text-cyan-500" />
          <span className="text-xl md:text-2xl text-muted-foreground tracking-widest uppercase">
            Video Editor
          </span>
          <Clapperboard className="w-6 h-6 text-violet-500" />
        </motion.div>
        
        {/* Description */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.7 }}
          className="text-lg text-muted-foreground max-w-2xl mx-auto mb-12"
        >
          Creative motion graphics video editor skilled in animation techniques and 
          color correction. Proven ability to manage project timelines and deliver 
          engaging multimedia content that captivates audiences.
        </motion.p>
        
        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.9 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <Button 
            size="lg" 
            className="btn-shine bg-gradient-to-r from-cyan-500 to-violet-500 hover:from-cyan-600 hover:to-violet-600 px-8"
            asChild
          >
            <a href="#contact">
              <Mail className="w-5 h-5 mr-2" />
              Get in Touch
            </a>
          </Button>
          <Button 
            size="lg" 
            variant="outline" 
            className="gradient-border hover:bg-white/5 px-8"
            asChild
          >
            <a href="#experience">
              <Briefcase className="w-5 h-5 mr-2" />
              View Experience
            </a>
          </Button>
        </motion.div>
        
        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-6 h-10 rounded-full border-2 border-muted-foreground/30 flex items-start justify-center p-2"
          >
            <motion.div
              animate={{ y: [0, 12, 0], opacity: [1, 0, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="w-1.5 h-1.5 rounded-full bg-cyan-500"
            />
          </motion.div>
        </motion.div>
      </motion.div>
    </section>
  );
};

// About Section
const AboutSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  
  const stats = [
    { label: 'Years Experience', value: '3+' },
    { label: 'Projects Completed', value: '50+' },
    { label: 'Companies', value: '3' },
  ];
  
  return (
    <section id="about" className="relative py-24 px-6" ref={ref}>
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-cyan-500 text-sm uppercase tracking-widest">About Me</span>
          <h2 className="text-4xl md:text-5xl font-bold mt-4">Professional Profile</h2>
        </motion.div>
        
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="aspect-square rounded-2xl overflow-hidden gradient-border">
              <div className="w-full h-full bg-gradient-to-br from-cyan-500/20 to-violet-500/20 flex items-center justify-center">
                <Film className="w-32 h-32 text-cyan-500/50" />
              </div>
            </div>
            
            {/* Floating elements */}
            <motion.div
              className="absolute -top-6 -right-6 w-24 h-24 rounded-xl glass flex items-center justify-center"
              animate={{ y: [0, -10, 0], rotate: [0, 5, 0] }}
              transition={{ duration: 4, repeat: Infinity }}
            >
              <Play className="w-10 h-10 text-cyan-500" />
            </motion.div>
            
            <motion.div
              className="absolute -bottom-6 -left-6 w-20 h-20 rounded-xl glass flex items-center justify-center"
              animate={{ y: [0, 10, 0], rotate: [0, -5, 0] }}
              transition={{ duration: 5, repeat: Infinity }}
            >
              <Sparkles className="w-8 h-8 text-violet-500" />
            </motion.div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <h3 className="text-2xl font-bold mb-6">
              Crafting Visual Stories with{' '}
              <span className="gradient-text">Precision & Creativity</span>
            </h3>
            
            <p className="text-muted-foreground mb-6 leading-relaxed">
              I am a passionate video editor based in Nagpur, India, with expertise in motion graphics, 
              visual effects, and color correction. My journey in video editing has equipped me with 
              the skills to transform raw footage into compelling narratives that engage and inspire audiences.
            </p>
            
            <p className="text-muted-foreground mb-8 leading-relaxed">
              With experience across news channels and media production houses, I have developed a keen 
              eye for detail and a deep understanding of storytelling techniques. I am proficient in 
              industry-standard software and always stay updated with the latest trends in video production.
            </p>
            
            {/* Stats */}
            <div className="grid grid-cols-3 gap-6">
              {stats.map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.4, delay: 0.6 + index * 0.1 }}
                  className="text-center p-4 rounded-xl glass hover-lift"
                >
                  <div className="text-3xl font-bold gradient-text">{stat.value}</div>
                  <div className="text-xs text-muted-foreground mt-1">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

// Experience Section
const ExperienceSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  
  const experiences = [
    {
      period: '2024 - Present',
      company: 'MNS NEWS TV',
      role: 'Motion Graphics',
      description: 'Created engaging motion graphics for various multimedia projects. Managed project timelines to ensure timely delivery of final products. Applied editing software to refine video quality and optimize clarity.',
      icon: Film,
    },
    {
      period: '2023 - 2024',
      company: 'Nagpur Samay',
      role: 'Video Editor',
      description: 'Implemented visual effects, animation, color correction techniques. Edited raw footage into cohesive narratives using Adobe Premiere Pro. Created engaging motion graphics for various multimedia projects.',
      icon: Clapperboard,
    },
    {
      period: '2021 - 2022',
      company: 'RAJKARNE MEDIA WAVES',
      role: 'Video Editor',
      description: 'Managed project timelines to ensure timely delivery of final products. Applied editing software to refine video quality and optimize clarity. Created engaging motion graphics for various multimedia projects.',
      icon: Play,
    },
  ];
  
  return (
    <section id="experience" className="relative py-24 px-6" ref={ref}>
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-cyan-500 text-sm uppercase tracking-widest">Career Path</span>
          <h2 className="text-4xl md:text-5xl font-bold mt-4">Work Experience</h2>
        </motion.div>
        
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-px timeline-line hidden md:block" />
          
          {experiences.map((exp, index) => (
            <motion.div
              key={exp.company}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className={`relative flex flex-col md:flex-row gap-8 mb-12 ${
                index % 2 === 0 ? 'md:flex-row-reverse' : ''
              }`}
            >
              {/* Timeline dot */}
              <div className="absolute left-8 md:left-1/2 w-4 h-4 rounded-full bg-cyan-500 -translate-x-1/2 hidden md:block animate-pulse-glow" />
              
              {/* Content */}
              <div className={`md:w-1/2 ${index % 2 === 0 ? 'md:pr-12' : 'md:pl-12'}`}>
                <div className="glass rounded-2xl p-6 hover-lift gradient-border">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500/20 to-violet-500/20 flex items-center justify-center">
                      <exp.icon className="w-6 h-6 text-cyan-500" />
                    </div>
                    <div>
                      <span className="text-sm text-cyan-500">{exp.period}</span>
                      <h3 className="text-xl font-bold">{exp.company}</h3>
                    </div>
                  </div>
                  <h4 className="text-lg font-semibold text-violet-400 mb-3">{exp.role}</h4>
                  <p className="text-muted-foreground text-sm leading-relaxed">{exp.description}</p>
                </div>
              </div>
              
              {/* Empty space for alternating layout */}
              <div className="hidden md:block md:w-1/2" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Skills Section
const SkillsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  
  const skills = [
    { name: 'Motion Graphics', icon: Sparkles, level: 95 },
    { name: 'Video Editing', icon: Film, level: 90 },
    { name: 'Visual Effects', icon: Wand2, level: 85 },
    { name: 'Animation Techniques', icon: Play, level: 88 },
    { name: 'Color Correction', icon: Palette, level: 92 },
    { name: 'Project Management', icon: Users, level: 80 },
  ];
  
  return (
    <section id="skills" className="relative py-24 px-6" ref={ref}>
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-cyan-500 text-sm uppercase tracking-widest">Expertise</span>
          <h2 className="text-4xl md:text-5xl font-bold mt-4">Skills & Abilities</h2>
        </motion.div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {skills.map((skill, index) => (
            <motion.div
              key={skill.name}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              className="glass rounded-2xl p-6 hover-lift gradient-border group"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-cyan-500/20 to-violet-500/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <skill.icon className="w-7 h-7 text-cyan-500" />
                </div>
                <h3 className="text-lg font-semibold">{skill.name}</h3>
              </div>
              
              <div className="relative h-2 bg-secondary rounded-full overflow-hidden">
                <motion.div
                  className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-cyan-500 to-violet-500"
                  initial={{ width: 0 }}
                  animate={isInView ? { width: `${skill.level}%` } : {}}
                  transition={{ duration: 1.5, delay: index * 0.1 + 0.3, ease: 'easeOut' }}
                />
              </div>
              
              <div className="flex justify-end mt-2">
                <span className="text-sm text-muted-foreground">{skill.level}%</span>
              </div>
            </motion.div>
          ))}
        </div>
        
        {/* Software icons */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-16 text-center"
        >
          <p className="text-muted-foreground mb-6">Proficient in industry-standard software</p>
          <div className="flex flex-wrap justify-center gap-4">
            {['Adobe Premiere Pro', 'After Effects', 'DaVinci Resolve', 'Final Cut Pro'].map((software, index) => (
              <motion.span
                key={software}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.3, delay: 0.8 + index * 0.1 }}
                className="px-4 py-2 rounded-full glass text-sm text-muted-foreground hover:text-foreground hover:border-cyan-500/50 transition-colors cursor-default"
              >
                {software}
              </motion.span>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

// Education Section
const EducationSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  
  const education = [
    {
      period: '2017 - 2020',
      degree: 'Bachelor of Vocation',
      institution: 'RTMNU University',
      description: 'Specialized in media production and video editing techniques.',
    },
    {
      period: '2007 - 2016',
      degree: 'High School Diploma',
      institution: 'Ram Manohar Lohia High School',
      description: 'Completed secondary education with focus on arts and creative subjects.',
    },
  ];
  
  return (
    <section id="education" className="relative py-24 px-6" ref={ref}>
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-cyan-500 text-sm uppercase tracking-widest">Academic Background</span>
          <h2 className="text-4xl md:text-5xl font-bold mt-4">Education</h2>
        </motion.div>
        
        <div className="grid md:grid-cols-2 gap-8">
          {education.map((edu, index) => (
            <motion.div
              key={edu.degree}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.2 }}
              className="glass rounded-2xl p-8 hover-lift gradient-border"
            >
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-violet-500/20 to-cyan-500/20 flex items-center justify-center flex-shrink-0">
                  <GraduationCap className="w-7 h-7 text-violet-500" />
                </div>
                <div>
                  <span className="text-sm text-cyan-500">{edu.period}</span>
                  <h3 className="text-xl font-bold mt-1">{edu.degree}</h3>
                  <p className="text-violet-400 font-medium mt-1">{edu.institution}</p>
                  <p className="text-muted-foreground text-sm mt-3">{edu.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Languages Section
const LanguagesSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  
  const languages = [
    { name: 'English', level: 'Elementary', progress: 70 },
    { name: 'Hindi', level: 'Beginner', progress: 50 },
    { name: 'Marathi', level: 'Beginner', progress: 45 },
  ];
  
  return (
    <section className="relative py-24 px-6" ref={ref}>
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-cyan-500 text-sm uppercase tracking-widest">Communication</span>
          <h2 className="text-4xl md:text-5xl font-bold mt-4">Languages</h2>
        </motion.div>
        
        <div className="grid md:grid-cols-3 gap-6">
          {languages.map((lang, index) => (
            <motion.div
              key={lang.name}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.4, delay: index * 0.15 }}
              className="glass rounded-2xl p-6 text-center hover-lift gradient-border"
            >
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-500/20 to-violet-500/20 flex items-center justify-center mx-auto mb-4">
                <Globe className="w-8 h-8 text-cyan-500" />
              </div>
              <h3 className="text-xl font-bold mb-2">{lang.name}</h3>
              <p className="text-muted-foreground text-sm mb-4">{lang.level}</p>
              <div className="relative h-2 bg-secondary rounded-full overflow-hidden">
                <motion.div
                  className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-cyan-500 to-violet-500"
                  initial={{ width: 0 }}
                  animate={isInView ? { width: `${lang.progress}%` } : {}}
                  transition={{ duration: 1, delay: index * 0.15 + 0.3 }}
                />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Contact Section
const ContactSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  
  const contacts = [
    { icon: Phone, label: 'Phone', value: '7057589256', href: 'tel:7057589256' },
    { icon: Mail, label: 'Email', value: 'sandeshmohankar23@gmail.com', href: 'mailto:sandeshmohankar23@gmail.com' },
    { icon: MapPin, label: 'Location', value: 'Nagpur, India 440035', href: '#' },
  ];
  
  return (
    <section id="contact" className="relative py-24 px-6" ref={ref}>
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-cyan-500 text-sm uppercase tracking-widest">Get in Touch</span>
          <h2 className="text-4xl md:text-5xl font-bold mt-4">Contact Me</h2>
          <p className="text-muted-foreground mt-4 max-w-xl mx-auto">
            Ready to bring your vision to life? Let&apos;s discuss your next project.
          </p>
        </motion.div>
        
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {contacts.map((contact, index) => (
            <motion.a
              key={contact.label}
              href={contact.href}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="glass rounded-2xl p-6 text-center hover-lift gradient-border group"
            >
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-500/20 to-violet-500/20 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <contact.icon className="w-8 h-8 text-cyan-500" />
              </div>
              <h3 className="text-lg font-semibold mb-1">{contact.label}</h3>
              <p className="text-muted-foreground text-sm">{contact.value}</p>
            </motion.a>
          ))}
        </div>
        
        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center"
        >
          <Button 
            size="lg" 
            className="btn-shine bg-gradient-to-r from-cyan-500 to-violet-500 hover:from-cyan-600 hover:to-violet-600 px-10 py-6 text-lg"
            asChild
          >
            <a href="mailto:sandeshmohankar23@gmail.com">
              <ExternalLink className="w-5 h-5 mr-2" />
              Send Message
            </a>
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

// Footer
const Footer = () => {
  return (
    <footer className="relative py-12 px-6 border-t border-border">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-center md:text-left">
            <h3 className="text-2xl font-bold gradient-text">SANDESH MOHANKAR</h3>
            <p className="text-muted-foreground text-sm mt-1">Video Editor & Motion Graphics Artist</p>
          </div>
          
          <div className="flex items-center gap-6">
            {[
              { icon: Mail, href: 'mailto:sandeshmohankar23@gmail.com' },
              { icon: Phone, href: 'tel:7057589256' },
            ].map((item, index) => (
              <motion.a
                key={index}
                href={item.href}
                className="w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-cyan-500/20 transition-colors"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
              >
                <item.icon className="w-5 h-5 text-muted-foreground hover:text-cyan-500" />
              </motion.a>
            ))}
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-border text-center">
          <p className="text-muted-foreground text-sm">
            &copy; {new Date().getFullYear()} Sandesh Mohankar. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

// Main App
function App() {
  return (
    <div className="relative min-h-screen bg-background text-foreground noise-overlay">
      <ParticleBackground />
      <Navigation />
      <main className="relative z-10">
        <HeroSection />
        <AboutSection />
        <ExperienceSection />
        <SkillsSection />
        <EducationSection />
        <LanguagesSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}

export default App;
